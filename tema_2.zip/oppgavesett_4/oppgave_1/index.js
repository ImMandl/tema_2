let syv = 1;

while (syv <= 10) {
    document.write(`
        <p>7 * ${syv} = ${7 * syv} </p>
    `
    );

    syv++;
}