let tall = 0;

while (tall <= 100) {
    document.write("<h3>" + (tall) + "</h3>");

    tall++;
}