const tekst = "DU GAMLA DU FRIA";

for (const bokstav of tekst) {
    document.write("<h3>" + bokstav + "</h3>");
}