document.write(`
    <article>
        <h1>Moby Dick</h1>
        <p>MOBY Dick er en roman om en diger hval.</p>
        <a href="moby.html">Les mer her</a>
    </article>
`);