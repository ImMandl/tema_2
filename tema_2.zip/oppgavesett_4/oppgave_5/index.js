const rutenett = document.querySelector("#rutenett");

let ruter = 30 * 30;

while (ruter > 0) {
    rutenett.innerHTML += `<div></div>`;

    ruter--;
}